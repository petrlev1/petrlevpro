-- phpMyAdmin SQL Dump
-- version 4.3.13
-- http://www.phpmyadmin.net
--
-- Host: k25.hostenko.com
-- Generation Time: Sep 30, 2016 at 08:05 PM
-- Server version: 5.6.30-cll-lve
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `andzsb9994_72221`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wp_terms`
--

REPLACE INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'все', 'all', 0),
(2, 'erherheh', 'erherheh', 0),
(3, 'post-format-image', 'post-format-image', 0),
(4, 'post-format-audio', 'post-format-audio', 0),
(5, 'post-format-link', 'post-format-link', 0),
(6, 'post-format-gallery', 'post-format-gallery', 0),
(7, 'post-format-aside', 'post-format-aside', 0),
(8, 'post-format-status', 'post-format-status', 0),
(9, 'menu1', 'menu1', 0),
(10, 'post-format-quote', 'post-format-quote', 0),
(11, '3d рисунки', '3d-risunki', 0),
(12, 'айдентика', 'aydentika', 0),
(13, 'измерение', 'izmerenie', 0),
(14, '3d', '3d', 0),
(15, 'типографика', 'tipografika', 0),
(16, 'иллюстрация', 'illyustratsiya', 0),
(17, 'заставка', 'zastavka', 0),
(18, 'стиль', 'stil', 0),
(19, 'iPad', 'ipad', 0),
(20, 'ручка', 'ruchka', 0),
(21, 'перо', 'pero', 0),
(22, 'рисовать', 'risovat', 0),
(23, 'сайт', 'sayt', 0),
(24, 'флэш', 'flesh', 0),
(25, 'flash', 'flash', 0),
(26, 'Картинка', 'kartinka', 0),
(27, 'вектор', 'vektor', 0),
(28, 'illustrator', 'illustrator', 0),
(29, 'художник', 'hudozhnik', 0),
(30, 'чертежи', 'chertezhi', 0),
(31, 'моделирование', 'modelirovanie', 0),
(32, 'One day pic', 'one-day-pic', 0),
(33, 'Графический дизайн', 'graficheskiy-dizayn', 0),
(34, 'почтовая рассылка', 'pochtovaya-rassyilka', 0),
(35, 'анимация', 'animatsiya', 0),
(36, 'gif', 'gif', 0),
(37, 'эффекты', 'effektyi', 0),
(38, 'графический', 'graficheskiy', 0),
(39, 'иконки', 'ikonki', 0),
(40, 'презентация', 'prezentatsiya', 0),
(41, 'иллюстрации', 'illyustratsii', 0),
(42, 'html верстка', 'html-verstka', 0),
(43, 'пиктограммы', 'piktogrammyi', 0),
(44, 'брошюра', 'broshyura', 0),
(45, 'полиграфия', 'poligrafiya', 0),
(46, 'дизайн интерфейсов', 'dizayn-interfeysov', 0),
(47, 'мобильные приложения', 'mobilnyie-prilozheniya', 0),
(48, 'best', 'best', 0),
(49, 'баннеры', 'banneryi', 0),
(50, 'html5', 'html5', 0),
(51, 'дизайн интерьера', 'dizayn-interera', 0),
(52, 'промышленный дизайн', 'promyishlennyiy-dizayn', 0),
(53, 'nowork', 'nowork', 0),
(54, 'стенды', 'stendyi', 0),
(55, 'blend4web', 'blend4web', 0),
(56, '3d моделирование', '3d-modelirovanie', 0),
(57, 'notes', 'notes', 0),
(58, 'рекламные материалы', 'reklamnyie-materialyi', 0),
(59, 'рбк', 'rbk', 0),
(60, 'эксперименты', 'eksperimentyi', 0),
(61, 'графи', 'grafi', 0),
(62, 'открытка', 'otkryitka', 0),
(63, 'логотип', 'logotip', 0),
(64, 'сайты', 'saytyi', 0),
(65, 'для души', 'dlya-dushi', 0),
(66, 'визуал', 'vizual', 0),
(67, 'полигра', 'poligra', 0),
(68, 'фото', 'foto', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`), ADD KEY `slug` (`slug`(191)), ADD KEY `name` (`name`(191));

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=69;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
